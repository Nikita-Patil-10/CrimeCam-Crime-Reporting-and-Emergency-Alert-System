// models/Report.js
import mongoose from "mongoose";

const CoordsSchema = new mongoose.Schema(
  {
    lat: Number,
    lng: Number,
  },
  { _id: false }
);

const ReportSchema = new mongoose.Schema(
  {
    // 👇 make optional so backend won’t reject
    name: { type: String, required: false },
    contact: { type: String, required: false },

    // 👇 your frontend sends "details", not "description"
    details: { type: String, required: true, trim: true, maxlength: 2000 },

    // 👇 allow capitalized crimes like "Assault"
    typeOfCrime: {
  type: String,
  enum: ["Theft", "Harassment", "Assault", "Fraud", "Rape", "Murder", "Other"],
  required: true,
},

    date: { type: Date, default: Date.now },
    locationText: { type: String, trim: true },
    coords: { type: CoordsSchema },
    mediaUrls: [{ type: String }],
    status: {
      type: String,
      enum: ["pending", "valid", "invalid"],
      default: "pending",
    },
    verificationScore: { type: Number, default: 0 },
    ipHash: { type: String },
  },
  { timestamps: true }
);

export default mongoose.model("Report", ReportSchema);
