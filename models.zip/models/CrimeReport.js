import mongoose from "mongoose";

const evidenceSchema = new mongoose.Schema({
  path: String,
  originalname: String,
  mimetype: String,
});

const crimeReportSchema = new mongoose.Schema({
  crimeType: String,
  date: String,
  time: String,
  description: String,
  location: String,
  latitude: String,
  longitude: String,
  evidence: evidenceSchema,
});

const CrimeReport = mongoose.model("CrimeReport", crimeReportSchema);

export default CrimeReport;