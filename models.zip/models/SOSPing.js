// models/SOSPing.js
import mongoose from "mongoose";

const pingSchema = new mongoose.Schema({
  lat: { type: Number, required: true },
  lon: { type: Number, required: true },
  accuracy: { type: Number },
  timestamp: { type: Date, default: Date.now },
});

const contactSchema = new mongoose.Schema({
  type: { type: String, enum: ["police", "relative"], required: true },
  number: { type: String, required: true },
});

const sosPingSchema = new mongoose.Schema({
  confirmed: { type: Boolean, default: false },

  location: {
    lat: { type: Number, required: true },
    lon: { type: Number, required: true },
    accuracy: { type: Number },
  },

  note: { type: String, default: "" },

  // 🔥 FIXED contacts schema
  contacts: [contactSchema], // not array of strings

  snapshots: [String],

  pings: [pingSchema],

  ipHash: { type: String },

  createdAt: { type: Date, default: Date.now },
});

const SOSPing = mongoose.model("SOSPing", sosPingSchema);
export default SOSPing;
