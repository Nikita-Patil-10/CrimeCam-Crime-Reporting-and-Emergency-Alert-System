// routes/snapshotRoute.js

import express from "express";
import multer from "multer";
import path from "path";
import SOSPing from "../models/SOSPing.js";

const router = express.Router();

// 🔹 Storage config
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "uploads/snapshots");
  },
  filename: function (req, file, cb) {
    const uniqueName = Date.now() + "-" + Math.round(Math.random() * 1e9) + ".jpg";
    cb(null, uniqueName);
  },
});

const upload = multer({ storage });

// 🔥 POST → /api/sos/:id/snapshot
router.post("/:id/snapshot", upload.single("snapshot"), async (req, res) => {
  try {
    const sosId = req.params.id;

    if (!req.file) {
      return res.status(400).json({ success: false, message: "No file uploaded" });
    }

    // Save file path in DB
    const doc = await SOSPing.findByIdAndUpdate(
      sosId,
      { $push: { snapshots: req.file.filename } },
      { new: true }
    );

    if (!doc) {
      return res.status(404).json({ success: false, message: "SOS ID not found" });
    }

    res.json({
      success: true,
      message: "Snapshot saved",
      filename: req.file.filename,
      snapshotCount: doc.snapshots.length,
    });
  } catch (error) {
    console.error("❌ Snapshot upload error:", error);
    res.status(500).json({ success: false, message: "Upload failed" });
  }
});

export default router;
