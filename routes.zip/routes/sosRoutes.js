// routes/sosRoutes.js
import express from "express";
import crypto from "crypto";
import multer from "multer";
import path from "path";
import dotenv from "dotenv";
import SOSPing from "../models/SOSPing.js";
import { sendSMS } from "../services/twilioService.js";

dotenv.config();
const router = express.Router();

// --------------------
// 🔹 MULTER STORAGE FOR SNAPSHOTS
// --------------------
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, "uploads/"),
  filename: (req, file, cb) => {
    const unique = `${Date.now()}-${Math.round(Math.random() * 1e9)}${path.extname(file.originalname)}`;
    cb(null, unique);
  },
});

const upload = multer({ storage });

// --------------------
// 🔹 START SOS ALERT
// POST → /api/sos/start
// --------------------
router.post("/start", async (req, res) => {
  try {
    const { confirm, lat, lon, accuracy, note, contacts } = req.body || {};

    if (!confirm) {
      return res.status(400).json({ success: false, message: "SOS not confirmed" });
    }
    if (typeof lat !== "number" || typeof lon !== "number") {
      return res.status(400).json({ success: false, message: "Missing GPS coordinates" });
    }

    // Hash user IP for anonimity
    const ip =
      req.headers["x-forwarded-for"]?.split(",")[0] ||
      req.socket.remoteAddress ||
      "";
    const ipHash = crypto.createHash("sha256").update(ip).digest("hex");

    // Save alert
    const doc = await SOSPing.create({
      confirmed: true,
      location: { lat, lon, accuracy },
      note: note || "",
      contacts: contacts || [],
      ipHash,
      createdAt: new Date(),
    });

    console.log("🚨 New SOS Alert Created:", doc._id);

    // --------------------
    // 🔹 SEND SMS TO CONTACTS
    // --------------------
    if (Array.isArray(contacts) && contacts.length > 0) {
      const locationUrl = `${process.env.BASE_URL}/sos/${doc._id}`;
      const messageBody = `🚨 EMERGENCY ALERT!\nVictim shared an SOS.\nLocation: ${locationUrl}\nNote: ${note || "No details"}\nPlease assist immediately.`;

      for (let contact of contacts) {
        console.log(`📩 Sending SMS to ${contact.number}`);
        await sendSMS(contact.number, messageBody);
      }
    }

    res.status(201).json({
      success: true,
      message: "SOS alert created & notifications sent.",
      id: doc._id,
    });

  } catch (err) {
    console.error("❌ SOS create error:", err);
    res.status(500).json({ success: false, message: "Failed to create SOS alert" });
  }
});

// --------------------
// 🔹 SNAPSHOT UPLOAD
// POST → /api/sos/:id/snapshot
// --------------------
router.post("/:id/snapshot", upload.single("snapshot"), async (req, res) => {
  try {
    const { id } = req.params;

    if (!req.file) {
      return res.status(400).json({ success: false, message: "No snapshot uploaded" });
    }

    const fileUrl = `${req.protocol}://${req.get("host")}/uploads/${req.file.filename}`;

    const sos = await SOSPing.findByIdAndUpdate(
      id,
      { $push: { snapshots: fileUrl } },
      { new: true }
    );

    if (!sos) {
      return res.status(404).json({ success: false, message: "SOS not found" });
    }

    console.log("📸 Snapshot uploaded:", fileUrl);

    res.json({
      success: true,
      file: fileUrl,
      sos,
    });

  } catch (err) {
    console.error("❌ Snapshot upload error:", err);
    res.status(500).json({ success: false, message: "Snapshot upload failed" });
  }
});

// --------------------
// 🔹 ADD LIVE LOCATION PING
// POST → /api/sos/:id/ping
// --------------------
router.post("/:id/ping", async (req, res) => {
  try {
    const { id } = req.params;
    const { lat, lon, accuracy } = req.body;

    if (typeof lat !== "number" || typeof lon !== "number") {
      return res.status(400).json({ success: false, message: "Invalid location data" });
    }

    const ping = { lat, lon, accuracy, timestamp: new Date() };

    const sos = await SOSPing.findByIdAndUpdate(
      id,
      { $push: { pings: ping } },
      { new: true }
    );

    if (!sos) {
      return res.status(404).json({ success: false, message: "SOS not found" });
    }

    console.log(`📍 Ping added to SOS ${id}`);

    res.json({ success: true, ping });

  } catch (err) {
    console.error("❌ Ping error:", err);
    res.status(500).json({ success: false, message: "Ping failed" });
  }
});

// --------------------
// 🔹 GET ALL SOS ALERTS
// GET → /api/sos/
// --------------------
router.get("/", async (req, res) => {
  try {
    const alerts = await SOSPing.find().sort({ createdAt: -1 });
    res.json({ success: true, alerts });
  } catch (err) {
    console.error("❌ Fetch error:", err);
    res.status(500).json({ success: false, message: "Failed to fetch SOS alerts" });
  }
});

export default router;
