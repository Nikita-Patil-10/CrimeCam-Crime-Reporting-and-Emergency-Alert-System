// routes/reportRoutes.js
import express from "express";
import multer from "multer";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";
import sharp from "sharp"; // <-- npm i sharp
import Report from "../models/Report.js";

const router = express.Router();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const uploadsPath = path.join(__dirname, "..", "uploads");
fs.mkdirSync(uploadsPath, { recursive: true });

// only allow images/videos, max ~20MB each
const fileFilter = (req, file, cb) => {
  const ok =
    file.mimetype.startsWith("image/") || file.mimetype.startsWith("video/");
  cb(ok ? null : new Error("Only images/videos are allowed"), ok);
};

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadsPath),
  filename: (req, file, cb) => {
    const unique = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, unique + path.extname(file.originalname).toLowerCase());
  },
});

const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: 20 * 1024 * 1024 }, // 20MB
});

// helper: optionally store full URLs instead of relative paths
function toPublicUrl(req, relPath) {
  const base = process.env.BASE_URL || `${req.protocol}://${req.get("host")}`;
  // store relative to keep it portable; flip to `${base}${relPath}` if you want full URL
  return relPath;
}

// POST /api/report-crime
router.post("/report-crime", upload.array("evidence", 10), async (req, res) => {
  try {
    console.log("📌 body:", req.body);
    console.log("📎 files:", req.files?.map(f => ({ name: f.originalname, path: f.path, type: f.mimetype })));

    const { typeOfCrime, details, date, time, location, lat, lng } = req.body;

    if (!typeOfCrime) {
      return res.status(400).json({ success: false, message: "typeOfCrime is required." });
    }
    if (!details) {
      return res.status(400).json({ success: false, message: "details are required." });
    }

    // process uploads: strip image EXIF (privacy) & compress; keep videos as-is
    const mediaUrls = [];
    for (const f of req.files || []) {
      if (f.mimetype.startsWith("image/")) {
        const outName = `img-${Date.now()}-${Math.round(Math.random() * 1e9)}.jpg`;
        const outPath = path.join(uploadsPath, outName);
        await sharp(f.path)
          .rotate()          // auto-rotate
          .jpeg({ quality: 80 }) // compress
          .toFile(outPath);
        fs.unlinkSync(f.path); // delete original with EXIF
        mediaUrls.push(toPublicUrl(req, `/uploads/${outName}`));
      } else {
        // video or other allowed files: keep original
        mediaUrls.push(toPublicUrl(req, `/uploads/${f.filename}`));
      }
    }

    const incidentDate = date ? new Date(`${date}T${time || "00:00"}`) : new Date();

    const report = new Report({
      typeOfCrime,
      details,
      date: incidentDate,
      locationText: location,
      coords: lat && lng ? { lat: parseFloat(lat), lng: parseFloat(lng) } : undefined,
      mediaUrls,
    });

    await report.save();
    console.log("✅ saved:", { id: report._id, mediaUrls });

    return res.status(201).json({
      success: true,
      message: "✅ Crime reported successfully!",
      reportId: report._id,
      mediaUrls,
    });
  } catch (err) {
    console.error("❌ Report submission failed:", err);
    return res.status(500).json({ success: false, message: err.message || "Failed to submit report." });
  }
});

// (optional) quick viewer for debugging in the browser
router.get("/reports", async (req, res) => {
  const docs = await Report.find().sort({ createdAt: -1 }).limit(20);
  res.json({ success: true, count: docs.length, data: docs });
});

export default router;
