import axios from "axios";

// Set base URL of backend
const API = axios.create({
  baseURL: "http://localhost:5000", 
});

export default API;
