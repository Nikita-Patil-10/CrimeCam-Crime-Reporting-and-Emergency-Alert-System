import { useState } from "react";
import Home from "./components/Home";
import ReportCrime from "./components/ReportCrimeForm";
import SOSPage from "./components/SOSPage";

function App() {
  const [page, setPage] = useState("home");
  const [scrollToSection, setScrollToSection] = useState(null);

  const handleNavigate = (target) => {
    console.log("Navigating to:", target); // Debug log
    if (target === "home" || target === "about" || target === "contact") {
      setPage("home");
      setScrollToSection(target === "home" ? "hero" : target);
    } else {
      setPage(target);
      setScrollToSection(null);
    }
  };

  const renderPage = () => {
    console.log("Rendering page:", page); // Debug log
    switch (page) {
      case "home":
        return <Home setPage={setPage} scrollToSection={scrollToSection} />;
      case "report":
        return <ReportCrime />;
      case "sos":
        return <SOSPage key={Date.now()} />; // Forces full re-render
      default:
        return <Home setPage={setPage} scrollToSection={scrollToSection} />;
    }
  };

  return (
    <div className="min-h-screen text-black">
      <nav className="text-white p-4 flex justify-between items-center fixed w-full top-0 z-10 bg-black">
        {/* <h1 className="text-xl font-bold cursor-pointer" onClick={() => handleNavigate("home")}>
          CrimeCam
        </h1> */}
        <img 
        src="/crimecamlogo.png"
        alt="CrimeCam Logo" 
        className="h-11 w-auto cursor-pointer" 
        // eslint-disable-next-line no-undef
        onClick={() => navigate("/")} // optional: click logo to go home
      />
        <div className="space-x-10">
          <button onClick={() => handleNavigate("home")} className="hover:underline">Home</button>
          <button onClick={() => handleNavigate("report")} className="hover:underline">Report a Crime</button>
          <button onClick={() => handleNavigate("sos")} className="hover:underline">SOS</button>
          <button onClick={() => handleNavigate("about")} className="hover:underline">About</button>
          <button onClick={() => handleNavigate("contact")} className="hover:underline">Contact</button>
        </div>
      </nav>

      <div className="pt-16 px-4 md:px-20">
        {renderPage()}
      </div>

      <footer className="bg-black text-white text-center py-2 mt-10">
        © 2025 CrimeCam. All rights reserved.
      </footer>
    </div>
  );
}

export default App;
