// src/api/sos.js
const API = "http://localhost:5000"; // change to your backend URL

export async function sendSOS(note) {
  const pos = await new Promise((resolve, reject) =>
    navigator.geolocation.getCurrentPosition(resolve, reject, {
      enableHighAccuracy: true,
      timeout: 10000
    })
  );

  const body = {
    confirm: true,
    lat: pos.coords.latitude,
    lng: pos.coords.longitude,
    accuracy: pos.coords.accuracy,
    note: note || ""
  };

  const res = await fetch(`${API}/api/sos/start`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });

  if (!res.ok) throw new Error("SOS failed");
  return res.json(); // { success, id }
}
