import { useState, useEffect, useRef } from 'react';
// eslint-disable-next-line no-unused-vars
import { motion, AnimatePresence } from 'framer-motion';

function Home({ setPage, scrollToSection }) {
  const heroRef = useRef(null);
  const aboutRef = useRef(null);
  const contactRef = useRef(null);

  const [currentSlide, setCurrentSlide] = useState(0);

  // Updated slides with refined titles, subtitles, descriptions based on CrimeCam project
  const slides = [
    {
      bg: "/slide1-bg.jpg",
      title: "Welcome to CrimeCam",
      titleHighlight: "CrimeCam",
      subtitle: "Anonymous Crime Reporting & Emergency Alerts",
      description:
        "Empowering communities to report crimes safely and anonymously, fostering safer neighborhoods through awareness and collaboration.",
      image: "/crimesclide (1).png", // Suggested new image for CrimeCam branding
      alt: "CrimeCam logo"
    },
    {
      bg: "/slide2-bg.jpg",
      title: "Report Crime Safely",
      titleHighlight: "Report Crime",
      subtitle: "Instant, Secure & Anonymous",
      description:
        "Submit crime reports instantly with photo, video, or text evidence — no personal data required. Help bring justice without fear.",
      image: "/crimesclide2.png", // Suggested image representing crime reporting
      alt: "Anonymous crime reporting"
    },
    {
      bg: "/slide3-bg.jpg",
      title: "Help Me!!!",
      titleHighlight: "SOS Alerts",
      subtitle: "Emergency Assistance in Real-Time",
      description:
        "Send immediate SOS alerts with live location and optional camera streaming to authorities and loved ones for rapid response.",
      image: "/sclide3(2).png", // Suggested image representing SOS emergency alert
      alt: "SOS emergency alert"
    }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [slides.length]);

  useEffect(() => {
    if (scrollToSection === 'hero' && heroRef.current) {
      heroRef.current.scrollIntoView({ behavior: 'smooth' });
    } else if (scrollToSection === 'about' && aboutRef.current) {
      aboutRef.current.scrollIntoView({ behavior: 'smooth' });
    } else if (scrollToSection === 'contact' && contactRef.current) {
      contactRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [scrollToSection]);

  // Animation variants for text lines
  const textVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: (i) => ({
      opacity: 1,
      y: 0,
      transition: { delay: i * 0.3, duration: 0.6, ease: "easeOut" }
    }),
    exit: { opacity: 0, y: -20, transition: { duration: 0.3 } }
  };

  // Animation variants for image
  const imageVariants = {
    hidden: { opacity: 0, scale: 0.9 },
    visible: { opacity: 1, scale: 1, transition: { duration: 0.8, ease: "easeOut" } },
    exit: { opacity: 0, scale: 0.9, transition: { duration: 0.5 } }
  };

  return (
    <div className="relative overflow-x-hidden min-h-screen text-white">
      <div className="fixed inset-0 -z-10 animate-bgColorChange"></div>

      {/* Hero Slider */}
      <section
        ref={heroRef}
        className="relative min-h-screen flex items-center justify-center px-6 overflow-hidden"
      >
        <AnimatePresence initial={false} mode="wait">
          {slides.map((slide, index) =>
            index === currentSlide ? (
              <motion.div
                key={slide.title}
                initial={{ opacity: 0, x: 100 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -100 }}
                transition={{ duration: 1.4, ease: "easeInOut" }}
                className="flex w-full max-w-7xl items-center justify-between gap-12"
              >
                {/* Left side: Text */}
                <div className="w-full md:w-2/3 space-y-8">

               
{/* Title */}
<motion.h1
  className="text-red-600 font-extrabold leading-tight font-serif"
  style={{ fontSize: "clamp(2.5rem, 4.5vw, 4.5rem)" }}
  custom={0}
  variants={textVariants}
  initial="hidden"
  animate="visible"
  exit="exit"
>
  {slide.title}
</motion.h1>


{/* Subtitle */}
{/* Subtitle */}
<motion.h2
  className="text-gray-200 mt-3"
  style={{ fontSize: "clamp(1.25rem, 3vw, 2.5rem)" }}
  custom={1}
  variants={textVariants}
  initial="hidden"
  animate="visible"
  exit="exit"
>
  {slide.subtitle}
</motion.h2>

{/* Description */}
<motion.p
  className="text-gray-300 leading-relaxed max-w-3xl mt-5"
  style={{ fontSize: "clamp(1rem, 2vw, 1.4rem)" }}
  custom={2}
  variants={textVariants}
  initial="hidden"
  animate="visible"
  exit="exit"
>
  {slide.description}
</motion.p>
                </div>

                {/* Right side: Image */}
                <motion.div
                  className="w-1/2 flex justify-center"
                  variants={imageVariants}
                  initial="hidden"
                  animate="visible"
                  exit="exit"
                >
                  <img
                    src={slide.image}
                    alt={slide.alt}
                    className="max-h-[200px] md:max-h-[250px] object-contain rounded-lg shadow-lg w-auto"
                  />
                </motion.div>
              </motion.div>
            ) : null
          )}
        </AnimatePresence>

        {/* Vertical Bullets */}
        <div
          aria-label="Slide navigation"
          className="absolute top-1/2 right-0 transform -translate-y-1/2 flex flex-col space-y-4 pr-4 z-20"
          style={{ width: '12px' }}
        >
          {slides.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentSlide(idx)}
              aria-label={`Go to slide ${idx + 1}`}
              className={`tp-bullet rounded-full w-3 h-3 border border-white transition-colors duration-300 ${
                currentSlide === idx ? 'bg-red-600' : 'bg-transparent'
              }`}
              style={{
                marginTop: idx === 0 ? 0 : '16px',
                cursor: 'pointer',
              }}
            />
          ))}
        </div>

       
        
      </section>

      {/* Cards Section */}
      <section
        className="cards-section bg-black bg-cover bg-center py-24 px-12 md:px-32 relative z-0"
        style={{ backgroundImage: "url('/whitecontainer.jpg')" }}
      >
        <div className="overlay absolute inset-0 bg-black bg-opacity-70 -z-10 rounded-xl"></div>
        <div className="cards-container flex flex-col md:flex-row justify-center items-center gap-12 relative z-10">
          <motion.div
            // whileHover={{ scale: 1.05, boxShadow: '0 20px 30px rgba(255, 240, 240, 1)' }}
            whileTap={{ scale: 0.95 }}
            initial={{ opacity: 0, y: 60 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            viewport={{ once: true }}
            className="card bg-gradient-to-tr from-white via-gray-100 to-white text-black rounded-2xl shadow-xl p-8 max-w-xs w-full text-center cursor-pointer transition-shadow duration-400 flex flex-col items-center"
            onClick={() => setPage("report")}
          >
            <img
              src="/reportcard(1) (1).png"
              alt="Report"
              className="card-img w-32 h-32 mb-6 rounded-lg transition-transform duration-300"
            />
           <button
  style={{
    background: "linear-gradient(135deg, #ff0000, #cc0000)", // gradient red
    color: "white",
    padding: "12px 25px",
    border: "none",
    borderRadius: "50px",
    fontSize: "16px",
    fontWeight: "bold",
    cursor: "pointer",
    boxShadow: "0 4px 8px rgba(0,0,0,0.3)",
    transition: "all 0.3s ease"
  }}
  onMouseOver={(e) =>
    (e.target.style.background = "linear-gradient(135deg, #cc0000, #990000)")
  }
  onMouseOut={(e) =>
    (e.target.style.background = "linear-gradient(135deg, #ff0000, #cc0000)")
  }
>
 Report Crime
</button>

            {/* <h3 className="text-xl font-extrabold tracking-wide">
              Report Crime
            </h3> */}
          </motion.div>

          <motion.div
            // whileHover={{ scale: 1.05, boxShadow: '0 20px 30px rgba(255, 255, 255, 1)' }}
            whileTap={{ scale: 0.95 }}
            initial={{ opacity: 0, y: 60 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            viewport={{ once: true }}
            className="card bg-gradient-to-tr from-white via-gray-100 to-white text-black rounded-2xl shadow-xl p-8 max-w-xs w-full text-center cursor-pointer transition-shadow duration-400 flex flex-col items-center"
            onClick={() => setPage("sos")}
          >
            <img
              src="/Soscard (2) (1).png"
              alt="SOS"
              className="card-img w-32 h-32 mb-6 rounded-lg transition-transform duration-300"
            />
            <button
  style={{
    background: "linear-gradient(135deg, #ff0000, #cc0000)", // gradient red
    color: "white",
    padding: "12px 25px",
    border: "none",
    borderRadius: "50px",
    fontSize: "16px",
    fontWeight: "bold",
    cursor: "pointer",
    boxShadow: "0 4px 8px rgba(0,0,0,0.3)",
    transition: "all 0.3s ease"
  }}
  onMouseOver={(e) =>
    (e.target.style.background = "linear-gradient(135deg, #cc0000, #990000)")
  }
  onMouseOut={(e) =>
    (e.target.style.background = "linear-gradient(135deg, #ff0000, #cc0000)")
  }
>
  Help me!!
</button>
            {/* <h2 className="text-xl font-extrabold tracking-wide">
              Help Me!!!
            </h2> */}
          </motion.div>
        </div>
        <style jsx>{`
          .cards-section {
            position: relative;
            border-radius: 1rem;
          }
          .overlay {
            border-radius: 1rem;
          }
          .card {
            box-shadow:
              0 4px 6px rgba(0, 0, 0, 0.1),
              0 1px 3px rgba(0, 0, 0, 0.06);
            cursor: pointer;
            user-select: none;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            transition: transform 0.3s ease;
          }
          .card:hover {
            box-shadow:
              0 15px 25px rgba(234, 72, 94, 0.5),
              0 10px 10px rgba(234, 72, 94, 0.3);
            transform: translateY(-5px);
          }
          .card-img {
            border-radius: 0.5rem;
            will-change: transform;
          }
          .card-img:hover {
            transform: scale(1.1);
            transition: transform 0.3s ease;
          }
        `}</style>
      </section>

      {/* About Section */}
      <section
        ref={aboutRef}
        className="min-h-screen flex flex-col md:flex-row justify-center items-center px-6 bg-cover bg-center relative"
        style={{ backgroundImage: "url('')" }}
      >
        <div className="absolute inset-0 bg-black bg-opacity-70 z-0 rounded-xl"></div>
        <div className="max-w-5xl mx-auto py-16 relative z-0 flex flex-col md:flex-row items-center md:items-start gap-12 text-gray-300">
          <div className="md:w-2/3 space-y-6">
            <h1 className="about-title font-extrabold text-white mb-2">
              About CrimeCam
            </h1>
            <p className="text-xl leading-relaxed">
              CrimeCam is a groundbreaking platform designed to empower individuals to report crimes anonymously and with confidence. We understand the fear and hesitation that often prevent witnesses or victims from coming forward. That’s why CrimeCam eliminates barriers — no names, emails, or logins required — just a direct, safe way to report incidents.
            </p>
            <p className="text-xl leading-relaxed">
              Our mission goes beyond reporting. When danger strikes, CrimeCam’s SOS feature lets users instantly alert authorities with live camera feeds and precise location, enabling faster response times and potentially saving lives. Additionally, users can notify their loved ones simultaneously for added security.
            </p>
            <p className="text-xl leading-relaxed">
              CrimeCam stands as a symbol of community courage and safety, helping create fear-free neighborhoods by holding wrongdoers accountable and ensuring help arrives quickly when it matters most.
            </p>
          </div>

          <div className="md:w-1/3 flex justify-center items-center">
            <img
              src="/aboutcc.webp"
              alt="Community safety visualization"
              className="about-image"
            />
          </div>
        </div>

        <style jsx>{`
          .about-title {
            font-size: 4rem;
          }
          @media (min-width: 768px) {
            .about-title {
              font-size: 5rem;
            }
          }
          .about-image {
            border-radius: 1rem;
            box-shadow: 0 4px 14px rgba(0, 0, 0, 0.3);
            max-width: 100%;
            height: auto;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            cursor: pointer;
          }
          .about-image:hover {
            transform: scale(1.0);
            box-shadow: 0 8px 30px rgba(255, 255, 255, 0.7);
          }
        `}</style>
      </section>

      {/* Contact Section */}
      <section
        ref={contactRef}
        className="contact-section max-w-7xl mx-auto py-20 px-6 md:px-12 flex flex-col md:flex-row items-start justify-between gap-6"
      >
        <motion.div
          className="contact-info md:w-[45%] w-full"
          initial={{ opacity: 0, x: -50 }}
          whileInView={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="contact-title about-title text-white mb-6 border-b border-gray-600 pb-4">
            Contact Us<br/>
          </h2>
          <p className="contact-desc text-lg leading-relaxed mb-10 text-gray-300 border-b border-gray-700 pb-6" style={{ fontSize: '1.5rem', maxWidth: '500px' }}>
            Feel free to use the form or drop us an email. Old-fashioned phone calls work too!
          </p>
          <div className="contact-details space-y-8">
            <div className="flex items-center gap-4 border-b border-gray-800 pb-4">
              <span className="icon text-gray-300 text-2xl" aria-hidden="true">📞</span>
              <a href="tel:+12345678901" className="contact-link text-gray-300 hover:text-red-600 transition-colors text-lg font-medium">
                +1 (234) 567-8901
              </a>
            </div>
            <div className="flex items-center gap-4 border-b border-gray-800 pb-4">
              <span className="icon text-gray-300 text-2xl" aria-hidden="true">✉</span>
              <a href="mailto:contact@example.com" className="contact-link text-gray-300 hover:text-red-600 transition-colors text-lg font-medium">
                contact@example.com
              </a>
            </div>
            <div className="flex items-center gap-4">
              <span className="icon text-gray-300 text-2xl" aria-hidden="true">📍</span>
              <address className="contact-address text-gray-300 not-italic text-lg font-medium">
                123 Main St, Anytown, USA
              </address>
            </div>
          </div>
        </motion.div>

        <motion.form
          className="contact-form md:w-[40%] w-full max-w-xs bg-gray-900 p-8 rounded-lg shadow-lg space-y-8"
          initial={{ opacity: 0, x: 50 }}
          whileInView={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
          onSubmit={(e) => {
            e.preventDefault();
            alert('Thank you for reaching out! Your message has been sent.');
            e.target.reset();
          }}
          noValidate
        >
          {['first-name', 'last-name', 'email'].map((field, index) => {
            const label = field.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase());
            const type = field === 'email' ? 'email' : 'text';
            return (
              <div key={index} className="form-group">
                <label htmlFor={field} className="form-label">{label}</label>
                <input
                  id={field}
                  name={field}
                  type={type}
                  placeholder={`Your ${label.toLowerCase()}`}
                  className="form-input"
                  required
                />
              </div>
            );
          })}

          <div className="form-group">
            <label htmlFor="message" className="form-label">Message</label>
            <textarea
              id="message"
              name="message"
              rows="6"
              placeholder="Your message"
              className="form-textarea"
              required
            ></textarea>
          </div>
          <motion.button
            type="submit"
            className="btn-submit"
            whileTap={{ scale: 0.95 }}
            whileHover={{ scale: 1.02 }}
          >
            Send Message
          </motion.button>
        </motion.form>

        <style jsx>{`
          .contact-section {
            gap: 1.5rem;
          }
          .contact-info {
            display: flex;
            flex-direction: column;
            justify-content: center;
          }
          .contact-title {
            font-weight: normal;
            line-height: 1.1;
            font-size: 4rem;
            border-bottom: none;
            padding-bottom: 0;
          }
          @media (min-width: 768px) {
            .contact-title {
              font-size: 5rem;
            }
          }
          .contact-desc {
            font-weight: 400;
          }
          .contact-details > div {
            align-items: center;
            display: flex;
          }
          .contact-link {
            text-decoration: none;
            transition: color 0.3s ease;
            font-weight: 500;
          }
          .contact-link:hover {
            color: #dc2626;
          }
          .contact-address {
            font-style: normal;
            font-weight: 500;
          }
          .contact-form {
            display: flex;
            flex-direction: column;
            justify-content: center;
            max-width: 100%;
          }
          .form-group {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
          }
          .form-label {
            font-size:  0.875 0.875rem;
            font-weight: 600;
            color: #d1d5db;
          }
          .form-input,
          .form-textarea {
            background-color: #000;
            border: 1.5px solid #4b5563;
            border-radius: 0.5rem;
            padding: 0.85rem 1.2rem;
            font-size: 1.125rem;
            color: #fff;
            transition: border-color 0.25s ease, box-shadow 0.25s ease;
            resize: none;
            outline-offset: 2px;
            width: 100%;
            box-sizing: border-box;
          }
          .form-input::placeholder,
          .form-textarea::placeholder {
            color: #6b7280;
          }
          .form-input:focus,
          .form-textarea:focus {
            border-color: #dc2626;
            box-shadow: 0 0 8px rgba(220, 38, 38, 0.5);
            outline: none;
          }
          .btn-submit {
            background-color: #dc2626;
            color: white;
            font-weight: 700;
            padding: 1rem 0;
            border-radius: 0.75rem;
            font-size: 1.25rem;
            cursor: pointer;
            box-shadow: 0 4px 14px rgba(220, 38, 38, 0.4);
            border: none;
            transition: background-color 0.3s ease, box-shadow 0.3s ease;
            user-select: none;
            width: 100%;
          }
          .btn-submit:hover {
            background-color: #b91c1c;
            box-shadow: 0 6px 20px rgba(185, 28, 28, 0.6);
          }
          .btn-submit:active {
            box-shadow: none;
          }
          @media (max-width: 768px) {
            .contact-section {
              flex-direction: column;
              gap: 2rem;
            }
            .contact-info,
            .contact-form {
              width: 100%;
            }
            .contact-form {
              max-width: 100%;
              padding: 1.5rem;
            }
          }
        `}</style>
      </section>

      <style jsx>{`
        @keyframes bgColorChange {
          0% {
            background-color: #054381ff;
          }
          25% {
            background-color: #023e7d;
          }
          50% {
            background-color: #002855;
          }
          75% {
            background-color: #001845;
          }
          100% {
            background-color: #001233;
          }
        }
        .animate-bgColorChange {
          animation: bgColorChange 15s ease infinite;
          position: fixed;
          inset: 0;
          z-index: -10;
          width: 100vw;
          height: 100vh;
          pointer-events: none;
        }
      `}</style>
    </div>
  );
}
export default Home;