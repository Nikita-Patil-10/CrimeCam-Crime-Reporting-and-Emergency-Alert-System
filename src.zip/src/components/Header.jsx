import { useNavigate } from "react-router-dom";

export default function Header() {
  const navigate = useNavigate();

  return (
   <header className="fixed top-0 w-full h-16 z-50 bg-red-600">
      <div className="space-x-6 text-lg">
        <button onClick={() => navigate("/")} className="hover:underline">Home</button>
        <button onClick={() => navigate("/report")} className="hover:underline">Report Crime</button>
        <button onClick={() => navigate("/sos")} className="hover:underline">SOS</button>
        <button onClick={() => navigate("/about")} className="hover:underline">About</button>
      </div>
      <h1 className="text-2xl font-bold">CrimeCam</h1>
      
    </header>
  );
}