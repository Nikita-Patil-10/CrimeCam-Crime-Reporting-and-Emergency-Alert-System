import React, { useEffect, useRef, useState } from "react";

/**
 * SOSPage.jsx
 * - Requests camera + location on user confirmation
 * - Shows live preview
 * - Lets user enter contacts + police number + message
 * - Sends POST /api/sos/start
 * - Uploads snapshot to /api/sos/:id/snapshot
 * - Sends periodic pings to /api/sos/:id/ping
 */

const API_BASE = "http://localhost:5000";

const SOSPage = () => {
  const videoRef = useRef(null);
  const pingIntervalRef = useRef(null); // ✅ Added

  const [isDanger, setIsDanger] = useState(false);
  const [cameraActive, setCameraActive] = useState(false);
  const [permissionGranted, setPermissionGranted] = useState(false);
  const [location, setLocation] = useState(null);
  const [streamObj, setStreamObj] = useState(null);
  // eslint-disable-next-line no-unused-vars
  const [sosId, setSosId] = useState(null); // ✅ Added

  const [policeNumber, setPoliceNumber] = useState("");
  const [relativeContacts, setRelativeContacts] = useState(["", "", ""]);
  const [messageNote, setMessageNote] = useState("");
  const [sending, setSending] = useState(false);

  // Request camera + location
  const requestPermissions = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "user" } });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.onloadedmetadata = () => videoRef.current.play().catch(console.error);
      }
      setStreamObj(stream);
      setCameraActive(true);
      setPermissionGranted(true);

      if ("geolocation" in navigator) {
        navigator.geolocation.getCurrentPosition(
          (pos) =>
            setLocation({
              lat: pos.coords.latitude,
              lng: pos.coords.longitude,
              acc: pos.coords.accuracy,
            }),
          (err) => console.warn("Geolocation error:", err),
          { enableHighAccuracy: true, timeout: 10000 }
        );
      } else console.warn("Geolocation not available");
    } catch (err) {
      console.error("getUserMedia error:", err);
      alert("Unable to access camera.");
      setCameraActive(false);
      setPermissionGranted(false);
      if (streamObj) stopStream(streamObj);
    }
  };

  const stopStream = (stream) => {
    if (!stream) return;
    stream.getTracks().forEach((t) => t.stop());
  };

  const handleEmergencyClick = () => {
    if (!isDanger) {
      if (!window.confirm("🚨 Are you sure you are in danger?")) return;
      setIsDanger(true);
      requestPermissions();
    } else {
      alert("SOS already active");
    }
  };

  const captureSnapshot = () => {
    if (!videoRef.current) return null;
    const video = videoRef.current;
    const w = video.videoWidth || 640;
    const h = video.videoHeight || 480;
    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d");
    ctx.drawImage(video, 0, 0, w, h);
    return new Promise((resolve) => canvas.toBlob((blob) => resolve(blob), "image/jpeg", 0.85));
  };

  const uploadSnapshot = async (id) => {
    try {
      const blob = await captureSnapshot();
      if (!blob) return null;
      const fd = new FormData();
      fd.append("snapshot", blob, "snapshot.jpg");
      const res = await fetch(`${API_BASE}/api/sos/${id}/snapshot`, { method: "POST", body: fd });
      if (!res.ok) return console.warn("Snapshot upload failed:", await res.text());
      return res.json();
    } catch (err) {
      console.error("uploadSnapshot err:", err);
      return null;
    }
  };

  // ✅ Added function to send automatic pings
  const sendPing = async (id) => {
    if (!location) return;
    try {
      await fetch(`${API_BASE}/api/sos/${id}/ping`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          lat: location.lat,
          lng: location.lng,
          accuracy: location.acc,
        }),
      });
      console.log("📍 Ping sent:", location);
    } catch (err) {
      console.error("Ping error:", err);
    }
  };

  const sendEmergencyToServer = async () => {
    const filledRelatives = relativeContacts.map((s) => s.trim()).filter(Boolean);
    if (!policeNumber.trim() && filledRelatives.length === 0) {
      return alert("Add at least one contact number (police or relative).");
    }

    if (!permissionGranted || !location) {
      try {
        const pos = await new Promise((resolve, reject) =>
          navigator.geolocation.getCurrentPosition(resolve, reject, { enableHighAccuracy: true, timeout: 10000 })
        );
        setLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude, acc: pos.coords.accuracy });
      } catch (e) {
        console.warn("Could not acquire location:", e);
      }
    }

    const contacts = [];
    if (policeNumber.trim()) contacts.push({ type: "police", number: policeNumber.trim() });
    filledRelatives.forEach((n) => contacts.push({ type: "relative", number: n }));

    const body = {
      confirm: true,
      lat: location?.lat,
      lng: location?.lng,
      accuracy: location?.acc,
      note: messageNote || "SOS sent from CrimeCam",
      contacts,
    };

    setSending(true);
    try {
      const res = await fetch(`${API_BASE}/api/sos/start`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (!res.ok || !data.success) throw new Error(data?.message || res.statusText);

      // ✅ Store SOS ID
      setSosId(data.id);

      // ✅ Start automatic ping every 30 seconds
      pingIntervalRef.current = setInterval(() => sendPing(data.id), 30000);

      if (cameraActive) await uploadSnapshot(data.id);
      alert("✅ SOS sent. Reference ID: " + data.id);
    } catch (err) {
      console.error("sendEmergencyToServer err:", err);
      alert("Failed to send SOS to server");
    } finally {
      setSending(false);
    }
  };

  // ✅ Updated handleCancel to stop pings
  const handleCancel = () => {
    if (streamObj) stopStream(streamObj);
    setIsDanger(false);
    setCameraActive(false);
    setPermissionGranted(false);
    setSosId(null);
    if (pingIntervalRef.current) {
      clearInterval(pingIntervalRef.current);
      pingIntervalRef.current = null;
    }
  };

  useEffect(() => {
    return () => {
      if (streamObj) stopStream(streamObj);
      if (pingIntervalRef.current) clearInterval(pingIntervalRef.current);
    };
  }, [streamObj]);

  const updateRelativeContact = (index, value) => {
    const copy = [...relativeContacts];
    copy[index] = value;
    setRelativeContacts(copy);
  };

  return (
    <div style={styles.page}>
      <div style={styles.card}>
        <h2 style={styles.title}>🚨 Emergency SOS</h2>

        {!isDanger ? (
          <>
            <p style={styles.lead}>Press the button below if you are in immediate danger.</p>
            <div style={{ textAlign: "center", marginTop: 30 }}>
              <button onClick={handleEmergencyClick} style={styles.dangerButton}>
                I am in Danger
              </button>
            </div>
          </>
        ) : (
          <>
            <div style={styles.rowBetween}>
              <div style={{ flex: 1 }}>
                <div style={{ color: "#198754", fontWeight: 700 }}>
                  ✅ Emergency alert active — authorities will be notified.
                </div>
                <div style={{ marginTop: 6, color: "#444" }}>
                  {location ? (
                    <div>📍 Latitude: {location.lat.toFixed(6)}, Longitude: {location.lng.toFixed(6)}</div>
                  ) : (
                    <div style={{ color: "#777" }}>Obtaining location…</div>
                  )}
                </div>
              </div>
            </div>

            <div style={styles.videoWrap}>
              <video ref={videoRef} autoPlay playsInline muted style={styles.video} />
            </div>

            <div style={styles.controlsSection}>
              <div style={styles.snapshotRow}>
                <button
                  onClick={async () => {
                    const blob = await captureSnapshot();
                    if (!blob) return alert("No snapshot available");
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement("a");
                    a.href = url;
                    a.download = "snapshot.jpg";
                    a.click();
                    URL.revokeObjectURL(url);
                  }}
                  style={styles.smallButton}
                >
                  📸 Save Snapshot
                </button>

                <button
                  onClick={() => {
                    captureSnapshot().then((b) => b && alert("Snapshot captured (not uploaded). Use Send Emergency to upload."));
                  }}
                  style={styles.smallButton}
                >
                  ⚡ Quick Capture
                </button>
              </div>

              <div style={styles.formGroup}>
                <label style={styles.label}>📝 Emergency Message</label>
                <textarea
                  placeholder="Describe what’s happening"
                  value={messageNote}
                  onChange={(e) => setMessageNote(e.target.value)}
                  style={styles.textarea}
                />
              </div>

              <div style={styles.formGroup}>
                <label style={styles.label}>👮 Police Number</label>
                <input
                  placeholder="Enter police number"
                  value={policeNumber}
                  onChange={(e) => setPoliceNumber(e.target.value)}
                  style={styles.input}
                />
              </div>

              <div style={styles.formGroup}>
                <label style={styles.label}>📱 Emergency Contacts</label>
                <div style={styles.contactsRow}>
                  {relativeContacts.map((c, i) => (
                    <input
                      key={i}
                      placeholder={`Contact ${i + 1}`}
                      value={c}
                      onChange={(e) => updateRelativeContact(i, e.target.value)}
                      style={styles.input}
                    />
                  ))}
                </div>
              </div>

              <div style={styles.actionsRow}>
                <button onClick={sendEmergencyToServer} disabled={sending} style={{ ...styles.sendButton, opacity: sending ? 0.7 : 1 }}>
                  {sending ? "Sending..." : "🚨 Send Alert"}
                </button>

                <button onClick={handleCancel} style={styles.stopButton}>
                  ⛔ Stop
                </button>
              </div>
            </div>
          </>
        )}
      </div>
      <style>
        {`@keyframes pulse { 
  0% { transform: scale(1); box-shadow: 0 0 20px rgba(255, 0, 0, 0.7); }
  50% { transform: scale(1.08); box-shadow: 0 0 45px rgba(255, 0, 0, 1); }
  100% { transform: scale(1); box-shadow: 0 0 20px rgba(255, 0, 0, 0.7); }
}

@keyframes sirenFlash {
  0% { background: linear-gradient(45deg, #ff0000, #b30000); }
  50% { background: linear-gradient(45deg, #b30000, #ff0000); }
  100% { background: linear-gradient(45deg, #ff0000, #b30000); }
}                                                                                                                                                                                 `}
      </style>
    </div>
  );
};

export default SOSPage;

/* ---------- Inline styles (simple, mobile-friendly) ---------- */

const styles = {
  page: {
    minHeight: "100vh",
    padding: 20,
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    background: "linear-gradient(120deg,#f4f7fb,#e9eef6)",
    fontFamily: "Inter, system-ui, Arial, sans-serif",
  },
  card: {
    width: "100%",
    maxWidth: 700,
    background: "#fff",
    borderRadius: 28,
    padding: 32,
    boxShadow: "0 18px 40px rgba(0, 0, 0, 1.28)",
    textAlign: "center", // centers heading & text
  },
  title: {
    margin: 0,
    marginBottom: 12,
    color: "#d6332a",
    fontSize: 28,
    fontWeight: 900,
    textAlign: "center",
  },
  lead: {
    fontSize: 16,
    color: "#444",
    textAlign: "center",
    lineHeight: 1.5,
  },
  dangerButton: {
    fontSize: 22,
    fontWeight: 800,
    color: "#fff",
    padding: "18px 40px",
    borderRadius: "14px",
    border: "none",
    cursor: "pointer",
    background: "linear-gradient(45deg, #ff0000, #b30000)",
    textTransform: "uppercase",
    letterSpacing: "1px",
    boxShadow: "0 0 25px rgba(255,0,0,0.6)",
    animation: "pulse 1.5s infinite, sirenFlash 2s infinite",
  },
  primaryButton: {
    background: "#d6332a",
    color: "#fff",
    border: "none",
    padding: "12px 18px",
    borderRadius: 10,
    cursor: "pointer",
    fontWeight: 700,
    boxShadow: "0 8px 22px rgba(214,51,42,0.18)",
  },
  secondaryButton: {
    background: "#fff",
    border: "1px solid #ddd",
    padding: "10px 14px",
    borderRadius: 10,
    cursor: "pointer",
  },
  ghostButton: {
    background: "#ffffffff",
    border: "1px solid #ccc",
    padding: "10px 14px",
    borderRadius: 10,
    cursor: "pointer",
  },
  videoWrap: {
    marginTop: 14,
    borderRadius: 12,
    overflow: "hidden",
    border: "3px solid rgba(214,51,42,0.12)",
    boxShadow: "0 10px 30px rgba(214,51,42,0.06)",
  },
  video: {
    display: "block",
    width: "100%",
    height: 360,
    objectFit: "cover",
    background: "#000",
  },
 
  controlsSection: {
  marginTop: 20,
  padding: 16,
  borderRadius: 14,
  background: "#002855",
  boxShadow: "0 6px 20px rgba(0,0,0,0.05)",
},

snapshotRow: {
  display: "flex",
  gap: 10,
  marginBottom: 15,
},

smallButton: {
  flex: 1,
  padding: "10px 14px",
  fontSize: 14,
  borderRadius: 10,
  border: "1px solid #ddd",
  background: "#fff",
  cursor: "pointer",
  transition: "all 0.2s",
},
formGroup: {
  marginBottom: 15,
  textAlign: "left",
},
contactsRow: {
  display: "flex",
  gap: 8,
},

label: {
  fontWeight: 700,
  marginBottom: 6,
  display: "block",
  color: "#ffffffff",
},

input: {
  flex: 1,
  padding: 10,
  borderRadius: 10,
  border: "1px solid #e0e0e0",
  outline: "none",
  fontSize: 14,
  boxShadow: "inset 0 1px 3px rgba(0,0,0,0.05)",
},

textarea: {
  width: "100%",
  minHeight: 80,
  padding: 12,
  borderRadius: 10,
  border: "1px solid #e0e0e0",
  resize: "vertical",
  outline: "none",
  fontSize: 14,
  boxShadow: "inset 0 1px 3px rgba(0,0,0,0.05)",
},

actionsRow: {
  display: "flex",
  gap: 12,
  marginTop: 20,
},

sendButton: {
  flex: 1,
  padding: "14px 20px",
  borderRadius: 12,
  border: "none",
  background: "linear-gradient(45deg, #ff4b2b, #ff0000)",
  color: "#fff",
  fontWeight: 800,
  fontSize: 16,
  cursor: "pointer",
  boxShadow: "0 8px 25px rgba(255,0,0,0.4)",
  transition: "transform 0.2s",
},

stopButton: {
  flex: 1,
  padding: "14px 20px",
  borderRadius: 12,
  border: "none",
  background: "#444",
  color: "#fff",
  fontWeight: 700,
  fontSize: 16,
  cursor: "pointer",
  boxShadow: "0 6px 18px rgba(0,0,0,0.25)",
},
  rowBetween: { display: "flex", justifyContent: "space-between", alignItems: "center" },
};
