// src/components/ReportCrimeForm.jsx
import React, { useState, useEffect, useRef } from "react"; 
import API from "../api"; // ✅ axios instance

const ReportCrimeForm = () => {
  const [typeOfCrime, setTypeOfCrime] = useState(""); // ✅ renamed
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [evidence, setEvidence] = useState([]);
  const [location, setLocation] = useState("");
  const [details, setDetails] = useState(""); // ✅ renamed
  const [latLng, setLatLng] = useState(null);

  const markerRef = useRef(null);
  const mapRef = useRef(null);
  const fileInputRef = useRef(null);

  // Load Leaflet dynamically
  useEffect(() => {
    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = "https://unpkg.com/leaflet@1.9.3/dist/leaflet.css";
    document.head.appendChild(link);

    const script = document.createElement("script");
    script.src = "https://unpkg.com/leaflet@1.9.3/dist/leaflet.js";
    script.onload = () => console.log("Leaflet loaded ✅");
    document.body.appendChild(script);

    return () => {
      document.head.removeChild(link);
      document.body.removeChild(script);
    };
  }, []);

  // Initialize map when location available
  useEffect(() => {
    if (!window.L || !latLng) return;

    if (mapRef.current) {
      mapRef.current.remove();
      mapRef.current = null;
      markerRef.current = null;
    }

    mapRef.current = window.L.map("map").setView([latLng.lat, latLng.lng], 16);

    window.L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution:
        '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
    }).addTo(mapRef.current);

    markerRef.current = window.L.marker([latLng.lat, latLng.lng], {
      draggable: true,
    }).addTo(mapRef.current);

    markerRef.current.on("dragend", function (e) {
      const pos = e.target.getLatLng();
      setLatLng({ lat: pos.lat, lng: pos.lng });
      setLocation(`Lat: ${pos.lat.toFixed(5)}, Lng: ${pos.lng.toFixed(5)}`);
    });

    setLocation(`Lat: ${latLng.lat.toFixed(5)}, Lng: ${latLng.lng.toFixed(5)}`);
  }, [latLng]);

  const handleUseCurrentLocation = () => {
    if (!navigator.geolocation) {
      alert("Geolocation not supported.");
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLatLng({ lat: pos.coords.latitude, lng: pos.coords.longitude });
      },
      () => alert("Unable to retrieve location.")
    );
  };

  // ✅ Submit Report
  const handleSubmit = async (e) => {
    e.preventDefault();

    const formData = new FormData();
    formData.append("typeOfCrime", typeOfCrime); // ✅ match schema
    formData.append("date", date);
    formData.append("time", time);
    formData.append("details", details); // ✅ match schema
    formData.append("location", location);

    if (latLng) {
      formData.append("lat", latLng.lat);
      formData.append("lng", latLng.lng);
    }

    if (evidence.length > 0) {
      for (let f of evidence) {
        formData.append("evidence", f);
      }
    }

    try {
      const res = await API.post("/api/report-crime", formData);

      if (res.data.success) {
        alert("✅ Thanks! Your crime report was submitted successfully.");
      } else {
        alert("❌ Failed: " + (res.data.message || "Unknown error"));
      }

      console.log("Response:", res.data);

      // Reset form after success
      setTypeOfCrime("");
      setDate("");
      setTime("");
      setDetails("");
      setLocation("");
      setLatLng(null);
      setEvidence([]);
      if (fileInputRef.current) fileInputRef.current.value = "";
    } catch (err) {
      console.error("Error reporting crime:", err);
      alert(
        "❌ Something went wrong. " +
          (err.response?.data?.message || err.message || "")
      );
    }
  };

  return (
    <>
      {/* 🔥 your styles unchanged */}
     <style>{`
        body {
          margin: 0;
          font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
          background: url('https://wallpaperaccess.com/full/2015338.jpg') no-repeat center center fixed;
          background-size: cover;
          color: #333;
        }
        .form-container { display: flex; align-items: center; justify-content: center; min-height: 100vh; padding: 20px; background: rgba(0,0,0,0.4);}
        .crime-report-form { background: rgba(255, 255, 255, 0.95); padding: 40px 50px; border-radius: 16px; box-shadow: 0 16px 40px rgba(0, 0, 0, 0.3); width: 100%; max-width: 700px;}
        .form-title { font-size: 2.8rem; font-weight: 800; color: #e3342f; text-align: center; margin-bottom: 25px; text-shadow: 1px 1px 3px rgba(0,0,0,0.2);}
        .form-label { display: block; font-weight: 600; margin-bottom: 8px; font-size: 1rem; color: #444;}
        .form-input,.form-select,.form-textarea { width: 100%; padding: 12px 15px; margin-bottom: 20px; border: 2px solid #ddd; border-radius: 12px; font-size: 1rem; font-weight: 500; transition: border-color 0.3s ease; resize: vertical;}
        .form-input:focus,.form-select:focus,.form-textarea:focus { outline: none; border-color: #e3342f; box-shadow: 0 0 8px #e3342faa;}
        .form-textarea { min-height: 100px;}
        .form-file-input { margin-bottom: 30px; font-size: 1rem; cursor: pointer;}
        .form-submit-button { width: 100%; background-color: #e3342f; border: none; color: white; font-weight: 700; font-size: 1.2rem; padding: 14px; border-radius: 24px; cursor: pointer; transition: background-color 0.3s ease; box-shadow: 0 6px 15px rgba(227, 52, 47, 0.5);}
        .form-submit-button:hover { background-color: #b82b24; box-shadow: 0 8px 20px rgba(184, 43, 36, 0.6);}
        .form-note { margin-top: 18px; text-align: center; font-size: 0.87rem; color: #666; font-style: italic;}
        #map { height: 300px; width: 100%; margin-bottom: 20px; border-radius: 12px; border: 2px solid #ddd; box-shadow: 0 0 15px #e3342faa;}
        .location-section { margin-bottom: 20px;}
        .btn-location { background-color: #4a90e2; border: none; color: white; font-weight: 600; padding: 10px 15px; border-radius: 12px; cursor: pointer; margin-bottom: 15px; transition: background-color 0.3s ease;}
        .btn-location:hover { background-color: #3a78c2;}
      `}</style>

      <div className="form-container">
        <form className="crime-report-form" onSubmit={handleSubmit}>
          <h2 className="form-title">Report a Crime</h2>

          <label className="form-label" htmlFor="crime-type">Type of Crime:</label>
          <select id="crime-type" className="form-select" value={typeOfCrime} onChange={(e) => setTypeOfCrime(e.target.value)} required>
            <option value="">Select Type</option>
            <option value="Theft">Theft</option>
            <option value="Assault">Assault</option>
            <option value="Harassment">Harassment</option>
            <option value="Fraud">Fraud</option> {/* ✅ added missing */}
            <option value="Rape">Rape</option>
            <option value="Murder">Murder</option>
            <option value="Other">Other</option>
          </select>

          <label className="form-label" htmlFor="date">Date:</label>
          <input id="date" type="date" className="form-input" value={date} onChange={(e) => setDate(e.target.value)} required />

          <label className="form-label" htmlFor="time">Time:</label>
          <input id="time" type="time" className="form-input" value={time} onChange={(e) => setTime(e.target.value)} required />

          <label className="form-label" htmlFor="details">Details:</label>
          <textarea id="details" className="form-textarea" value={details} onChange={(e) => setDetails(e.target.value)} placeholder="Provide details..." required />

          <label className="form-label" htmlFor="evidence">Upload Evidence:</label>
          <input id="evidence" type="file" className="form-file-input" ref={fileInputRef} onChange={(e) => setEvidence(Array.from(e.target.files))} accept="image/*,video/*" multiple />

          <div className="location-section">
            <button type="button" className="btn-location" onClick={handleUseCurrentLocation}>
              Use My Current Location
            </button>

            {latLng && <div id="map"></div>}

            <label className="form-label" htmlFor="location">Location:</label>
            <input id="location" type="text" className="form-input" value={location} onChange={(e) => setLocation(e.target.value)} placeholder="Enter manually or use GPS" required />
          </div>

          <button type="submit" className="form-submit-button">Submit Report</button>
          <p className="form-note">* Report will be verified before action.</p>
        </form>
      </div>
    </>
  );
};
export default ReportCrimeForm;
