export default function IntroSection() {
  return (
    <div className="text-center text-white mb-8">
      <h1 className="text-4xl font-bold">Welcome to CrimeCam</h1>
      <p className="text-xl">Your Safety, Our Priority</p>
    </div>
  );
}